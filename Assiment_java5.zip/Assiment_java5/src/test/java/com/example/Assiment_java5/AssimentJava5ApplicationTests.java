package com.example.Assiment_java5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssimentJava5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
